#!/usr/bin/env bash
set -u

echo "======================================"
echo " Public IP check"
echo "======================================"

services=(
  "https://api.ipify.org"
  "https://ifconfig.me/ip"
  "https://icanhazip.com"
)

for url in "${services[@]}"; do
  echo -n "$url -> "
  curl -fsS --max-time 8 "$url" 2>/dev/null || echo "FAILED"
done

echo
echo "提示：以上检测的是执行此脚本的机器的公网出口 IP。"
echo "如果你需要从客户端确认出口，请在客户端实际连接后再检测。"
