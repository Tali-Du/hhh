#!/usr/bin/env bash
set -euo pipefail

if [ "${EUID:-999}" -ne 0 ]; then
  echo "请使用 root 运行此脚本。"
  exit 1
fi

if [ ! -f /etc/os-release ]; then
  echo "无法识别操作系统。"
  exit 1
fi

. /etc/os-release

case "${ID:-}" in
  debian)
    case "${VERSION_ID:-}" in
      12|13) ;;
      *)
        echo "本项目重点支持 Debian 12 / Debian 13。当前版本：${VERSION_ID:-unknown}"
        read -r -p "仍然继续？输入 YES 继续： " confirm
        [ "$confirm" = "YES" ] || exit 1
        ;;
    esac
    ;;
  *)
    echo "当前系统不是 Debian。"
    read -r -p "3X-UI 官方支持其他发行版；仍然继续？输入 YES： " confirm
    [ "$confirm" = "YES" ] || exit 1
    ;;
esac

echo "==> Architecture: $(uname -m)"
echo "==> OS: ${PRETTY_NAME:-unknown}"
echo
echo "即将调用 3X-UI 官方安装脚本。"
echo "官方来源：MHSanaei/3x-ui"
echo

export XUI_NONINTERACTIVE=1
bash <(curl -fsSL https://raw.githubusercontent.com/MHSanaei/3x-ui/master/install.sh)

echo
echo "======================================"
echo " 3X-UI 安装完成/安装器已退出"
echo "======================================"
echo
echo "查看管理菜单：x-ui"
echo "查看服务状态：systemctl status x-ui"
echo "如需查看无人值守安装结果：cat /etc/x-ui/install-result.env"
