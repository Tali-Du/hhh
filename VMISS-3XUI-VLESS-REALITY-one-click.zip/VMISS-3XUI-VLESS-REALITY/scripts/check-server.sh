#!/usr/bin/env bash
set -u

echo "======================================"
echo " VMISS / Linux server check"
echo "======================================"

if [ "${EUID:-999}" -ne 0 ]; then
  echo "[WARN] 当前不是 root。某些检查可能无法完成。"
else
  echo "[OK] root 权限"
fi

if [ -r /etc/os-release ]; then
  . /etc/os-release
  echo "[INFO] OS: ${PRETTY_NAME:-unknown}"
  echo "[INFO] ID: ${ID:-unknown}"
  echo "[INFO] VERSION_ID: ${VERSION_ID:-unknown}"
else
  echo "[ERROR] 找不到 /etc/os-release"
  exit 1
fi

echo "[INFO] Kernel: $(uname -r)"
echo "[INFO] Architecture: $(uname -m)"

case "$(uname -m)" in
  x86_64|amd64) echo "[OK] amd64 / x86_64" ;;
  aarch64|arm64) echo "[OK] arm64 / aarch64" ;;
  *) echo "[WARN] 当前架构不在本教程重点测试范围内" ;;
esac

echo
echo "[INFO] Disk:"
df -h /

echo
echo "[INFO] Memory:"
free -h 2>/dev/null || true

echo
echo "[INFO] Listening TCP ports:"
ss -lnt 2>/dev/null || netstat -lnt 2>/dev/null || true

echo
echo "[INFO] Public IPv4:"
curl -4 -fsS --max-time 8 https://api.ipify.org 2>/dev/null || echo "无法获取"

echo
echo "[INFO] 3X-UI service:"
if systemctl is-active --quiet x-ui 2>/dev/null; then
  echo "[OK] x-ui 正在运行"
elif systemctl list-unit-files 2>/dev/null | grep -q '^x-ui.service'; then
  echo "[WARN] x-ui 已安装但当前未运行"
else
  echo "[INFO] 尚未检测到 x-ui 服务"
fi
