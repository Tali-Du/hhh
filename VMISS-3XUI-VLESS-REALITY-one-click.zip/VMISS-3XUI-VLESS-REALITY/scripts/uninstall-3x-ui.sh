#!/usr/bin/env bash
set -euo pipefail

if [ "${EUID:-999}" -ne 0 ]; then
  echo "请使用 root 运行。"
  exit 1
fi

echo "警告：这会调用 3X-UI 的卸载功能。"
read -r -p "确定卸载？输入 UNINSTALL： " confirm
[ "$confirm" = "UNINSTALL" ] || { echo "已取消。"; exit 0; }

if command -v x-ui >/dev/null 2>&1; then
  x-ui uninstall
else
  echo "未找到 x-ui 命令。"
fi
