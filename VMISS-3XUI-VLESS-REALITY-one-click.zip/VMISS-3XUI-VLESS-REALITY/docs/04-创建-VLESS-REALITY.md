# 04｜创建 VLESS + TCP + REALITY

进入 3X-UI：

**入站列表 → 添加入站**

建议按以下结构创建：

## 基础

- Protocol：VLESS
- Port：选择一个你自己的未占用 TCP 端口
- Remark：例如 `vless-reality`

## Client

新增一个 Client：

- Email：例如 `client-01`
- Flow：留空（如果你的客户端/版本没有明确要求，不要随意填写）

UUID 由 3X-UI 自动生成。

## Transmission

- Network：TCP

## Security

- Security：REALITY

让 3X-UI 生成 REALITY 密钥。

## REALITY 参数

不要照抄网上固定的 Private Key、Public Key 或 UUID。

由你自己的 3X-UI 实例生成。

Target / Server Names / Short ID 应选择一个你实际验证可用、且符合当前 Xray/REALITY 配置要求的目标。

> 不建议把某个网站作为“永远正确”的固定模板写死。上游实现和可用性会变化。

## 保存

保存入站后，让 3X-UI 生成客户端分享链接或二维码。

然后再到 v2rayN 导入。

### 安全提醒

以下信息不要上传 GitHub：

- UUID
- REALITY Private Key
- 服务器公网 IP（如果你不希望公开）
- 面板用户名
- 面板密码
- 订阅链接
