# 08｜上传到 GitHub

## 方法 A：网页上传（最适合新手）

1. 登录 GitHub。
2. 点击 `New repository`。
3. 创建一个仓库，例如：

```text
VMISS-3XUI-VLESS-REALITY
```

4. 建议选择 Public，方便别人查看教程。
5. **不要勾选**自动创建 README，因为本项目已经有 README。
6. 创建仓库。
7. 点击 `Add file` → `Upload files`。
8. 把整个项目文件夹里的内容拖进去。
9. 提交。

## 方法 B：Git 命令

在项目目录执行：

```bash
git init
git add .
git commit -m "Initial release"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/VMISS-3XUI-VLESS-REALITY.git
git push -u origin main
```

第一次 push 时按 GitHub 的登录/认证提示操作。

## 上传前检查

执行：

```bash
git status
```

确认没有：

```text
.env
*.key
*.pem
credentials
secrets
真实订阅链接
真实 UUID
REALITY Private Key
```

## 最重要

公开 GitHub 项目里只放：

- 教程
- 脚本
- 示例
- 占位符
- 官方链接

不要放你自己的真实服务器配置。
