# Contributing

欢迎提交：

- Debian 12/13 兼容性修正
- 新手文档改进
- 拼写和命令错误修正
- 安全性改进

请不要提交：

- 真实 VPS IP
- UUID
- REALITY Private Key
- 账号密码
- 订阅链接
- 个人服务器截图中的敏感信息

所有修改应尽量保持对 Linux 新手友好。
