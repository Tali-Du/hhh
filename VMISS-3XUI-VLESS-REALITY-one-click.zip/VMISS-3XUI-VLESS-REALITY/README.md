# VMISS / 3X-UI / VLESS + TCP + REALITY 一键部署

一个面向 Linux 新手的**私有自托管测试项目**。

目标：在你有权限管理的 VPS 上，用**一条命令**安装 3X-UI，并自动创建一套全新的 VLESS + TCP + REALITY 测试节点。

> 本仓库不保存任何真实 IP、UUID、REALITY 私钥、面板密码或 API Token。

## 一条命令

假设你的 GitHub 仓库地址是：

`https://github.com/YOUR_USERNAME/YOUR_REPO`

SSH 登录 Debian VPS 后，直接复制：

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/YOUR_USERNAME/YOUR_REPO/main/install.sh)
```

正常情况下，这一条命令会完成：

1. 检查 root、系统和基础依赖
2. 调用 3X-UI 官方无人值守安装器
3. 获取 3X-UI 自动生成的管理地址、用户名和密码
4. 自动生成新的 UUID
5. 自动生成新的 X25519 REALITY 密钥对
6. 自动生成新的 short ID
7. 创建 VLESS + TCP + REALITY 入站
8. 创建并绑定 VLESS 客户端
9. 输出 `vless://` 分享链接
10. 把本地节点信息保存到 `/root/vmess-reality-result.txt`

3X-UI 官方当前支持 `XUI_NONINTERACTIVE=1` 无交互安装，并将安装结果保存到 `/etc/x-ui/install-result.env`；官方也支持通过 API 创建入站和客户端。 citeturn0search1turn3view0turn1search1

## 可选参数

默认 REALITY 端口是 `45684`，默认测试目标是 `www.microsoft.com:443`。REALITY 要求目标站点可访问，并且 SNI 与目标证书匹配。 citeturn0search0turn0search2

如果想指定端口：

```bash
REALITY_PORT=443 bash <(curl -fsSL https://raw.githubusercontent.com/YOUR_USERNAME/YOUR_REPO/main/install.sh)
```

如果需要更换目标：

```bash
REALITY_TARGET=www.microsoft.com:443 REALITY_SNI=www.microsoft.com bash <(curl -fsSL https://raw.githubusercontent.com/YOUR_USERNAME/YOUR_REPO/main/install.sh)
```

## 导入 v2rayN

一键脚本最后会输出完整的 `vless://` 分享链接。

复制整个链接 → 打开 v2rayN → 导入服务器/剪贴板链接 → 连接。

REALITY 客户端使用的是公钥；私钥只保留在服务器端。 citeturn0search0turn0search10

## 架构

```text
VPS
 │
 ├── 3X-UI
 │    └── Xray
 │         └── VLESS + TCP + REALITY
 │
 └── vless:// 分享链接
              │
              ▼
            v2rayN
```

## 安全原则

- 仅用于你有权限管理的服务器和网络。
- 不公开提供开放代理服务。
- 不把 VPS 密码、3X-UI 密码、API Token、UUID、REALITY 私钥提交到 GitHub。
- 不把 `/etc/x-ui/install-result.env` 上传到 GitHub。
- 不把 `/root/vmess-reality-result.txt` 上传到 GitHub。
- 不复用已经公开泄露的 REALITY 私钥、UUID 或 short ID。
- 如果真实密钥曾经公开过，部署前重新生成。

## 手动教程

如果不想使用一键脚本，完整教程仍然保留在 `docs/`：

- `docs/01-准备工作.md`
- `docs/02-检查系统.md`
- `docs/03-安装-3X-UI.md`
- `docs/04-创建-VLESS-REALITY.md`
- `docs/05-v2rayN.md`
- `docs/06-故障排查.md`
- `docs/07-安全与维护.md`
- `docs/08-GitHub上传.md`

## 上游项目

3X-UI 官方项目：
https://github.com/MHSanaei/3x-ui

3X-UI 官方安装文档：
https://github.com/MHSanaei/3x-ui/wiki/Installation

本项目只是部署包装脚本，不复制或修改 3X-UI 源代码。
