#!/usr/bin/env bash
set -euo pipefail

# VMISS-3XUI-VLESS-REALITY one-click bootstrap
# Installs 3X-UI from the official upstream installer.
# Secrets are generated on the server and never written to this repository.

if [ "${EUID:-999}" -ne 0 ]; then
  echo "请用 root 运行。"
  exit 1
fi

if ! command -v curl >/dev/null 2>&1; then
  echo "正在安装 curl..."
  if command -v apt-get >/dev/null 2>&1; then
    apt-get update -qq
    apt-get install -y -qq curl ca-certificates
  else
    echo "找不到 apt-get，请先安装 curl。"
    exit 1
  fi
fi

if [ ! -f /etc/os-release ]; then
  echo "无法识别操作系统。"
  exit 1
fi
. /etc/os-release

case "${ID:-}" in
  debian|ubuntu|armbian|fedora|centos|rhel|almalinux|rocky|ol|amzn|arch|manjaro|opensuse-tumbleweed|opensuse-leap|alpine)
    ;;
  *)
    echo "当前系统：${PRETTY_NAME:-unknown}"
    echo "请确认它属于 3X-UI 官方支持范围。"
    exit 1
    ;;
esac

echo
printf '%s\n' '============================================='
printf '%s\n' ' VMISS / 3X-UI 一键部署'
printf '%s\n' '============================================='
printf '系统：%s\n' "${PRETTY_NAME:-unknown}"
printf '架构：%s\n' "$(uname -m)"
echo

echo '正在调用 3X-UI 官方安装器...'
export XUI_NONINTERACTIVE=1
export XUI_SSL_MODE="${XUI_SSL_MODE:-none}"
curl -fsSL https://raw.githubusercontent.com/MHSanaei/3x-ui/main/install.sh | bash

echo
echo '============================================='
echo ' 3X-UI 安装完成'
echo '============================================='
echo

if [ -f /etc/x-ui/install-result.env ]; then
  # shellcheck disable=SC1091
  . /etc/x-ui/install-result.env
  echo "管理地址：${XUI_ACCESS_URL:-请执行 x-ui 查看}"
  echo "用户名：${XUI_USERNAME:-请执行 x-ui 查看}"
  echo "密码：${XUI_PASSWORD:-请执行 x-ui 查看}"
  echo
  echo '上述信息只存在于服务器本地。不要复制到 GitHub。'
else
  echo '未找到安装结果文件，请执行：x-ui'
fi

echo

RESULT=/etc/x-ui/install-result.env
if [ ! -f "$RESULT" ]; then
  echo "3X-UI 安装完成，但未找到安装结果文件。请执行 x-ui 检查。"; exit 0
fi
# shellcheck disable=SC1091
. "$RESULT"

need_cmd(){ command -v "$1" >/dev/null 2>&1 || { echo "缺少命令：$1"; exit 1; }; }
need_cmd curl
need_cmd openssl

XRAY_BIN="$(command -v xray || true)"
if [ -z "$XRAY_BIN" ]; then
  for p in /usr/local/x-ui/bin/xray /usr/bin/xray /opt/x-ui/bin/xray; do
    [ -x "$p" ] && XRAY_BIN="$p" && break
  done
fi
[ -n "$XRAY_BIN" ] || { echo '找不到 xray 可执行文件。'; exit 1; }

PANEL_BASE="${XUI_ACCESS_URL%/}"
API_ROOT="${PANEL_BASE}/panel/api"
AUTH_HEADER="Authorization: Bearer ${XUI_API_TOKEN}"

# Generate fresh client UUID, short ID and REALITY keypair locally on this server.
UUID="$(cat /proc/sys/kernel/random/uuid)"
SHORT_ID="$(openssl rand -hex 8)"
KEY_OUTPUT="$($XRAY_BIN x25519 2>/dev/null || true)"
PRIVATE_KEY="$(printf '%s\n' "$KEY_OUTPUT" | sed -nE 's/^Private key:[[:space:]]*//p' | head -n1)"
PUBLIC_KEY="$(printf '%s\n' "$KEY_OUTPUT" | sed -nE 's/^Public key:[[:space:]]*//p' | head -n1)"

if [ -z "$PRIVATE_KEY" ] || [ -z "$PUBLIC_KEY" ]; then
  echo 'xray x25519 输出无法识别。请执行：xray x25519，并把输出格式发给项目维护者。'
  exit 1
fi

PORT="${REALITY_PORT:-45684}"
TARGET="${REALITY_TARGET:-www.microsoft.com:443}"
SNI="${REALITY_SNI:-www.microsoft.com}"
REMARK="${REALITY_REMARK:-VLESS-REALITY-private}"

if ss -lnt 2>/dev/null | awk '{print $4}' | grep -Eq ":${PORT}$"; then
  echo "端口 ${PORT} 已被占用。可这样换端口：REALITY_PORT=443 bash scripts/setup-reality.sh"
  exit 1
fi

# Verify the chosen target is reachable before creating the inbound.
TARGET_HOST="${TARGET%:*}"
if ! curl -4 -fsS --connect-timeout 8 -o /dev/null "https://${TARGET_HOST}/"; then
  echo "无法从本服务器访问 https://${TARGET_HOST}/"
  echo "请换一个你确认可访问、证书与 SNI 匹配的 TLS 站点。"
  exit 1
fi

TMP_JSON="$(mktemp)"
trap 'rm -f "$TMP_JSON"' EXIT

python3 - "$TMP_JSON" "$PORT" "$REMARK" "$TARGET" "$SNI" "$PRIVATE_KEY" "$SHORT_ID" <<'PY'
import json, sys
out, port, remark, dest, sni, private_key, short_id = sys.argv[1:]
payload = {
  "enable": True,
  "remark": remark,
  "listen": "",
  "port": int(port),
  "protocol": "vless",
  "expiryTime": 0,
  "total": 0,
  "settings": {"clients": [], "decryption": "none", "fallbacks": []},
  "streamSettings": {
    "network": "tcp",
    "security": "reality",
    "realitySettings": {
      "show": False,
      "xver": 0,
      "dest": dest,
      "serverNames": [sni],
      "privateKey": private_key,
      "shortIds": [short_id],
      "fingerprint": "chrome",
      "spiderX": "/"
    }
  },
  "sniffing": {"enabled": True, "destOverride": ["http", "tls", "quic"], "metadataOnly": False, "routeOnly": False}
}
json.dump(payload, open(out, 'w'), ensure_ascii=False)
PY

ADD_RESULT="$(curl -fsS -X POST "$API_ROOT/inbounds/add" -H "$AUTH_HEADER" -H 'Content-Type: application/json' --data-binary "@$TMP_JSON")"
if ! printf '%s' "$ADD_RESULT" | grep -q '"success"[[:space:]]*:[[:space:]]*true'; then
  echo '创建入站失败：'
  printf '%s\n' "$ADD_RESULT"
  exit 1
fi

# Read the created inbound ID and attach the generated VLESS client.
INBOUND_ID="$(printf '%s' "$ADD_RESULT" | python3 -c 'import json,sys; d=json.load(sys.stdin); print((d.get("obj") or {}).get("id", ""))')"
[ -n "$INBOUND_ID" ] || { echo '入站已返回成功，但无法解析 inbound ID。'; exit 1; }

CLIENT_JSON="$(python3 - "$INBOUND_ID" "$UUID" <<'PY'
import json,sys
print(json.dumps({"inboundIds":[int(sys.argv[1])],"id":sys.argv[2],"email":"private-client","enable":True}, ensure_ascii=False))
PY
)"

CLIENT_RESULT="$(curl -fsS -X POST "$API_ROOT/clients/add" -H "$AUTH_HEADER" -H 'Content-Type: application/json' -d "$CLIENT_JSON")"
if ! printf '%s' "$CLIENT_RESULT" | grep -q '"success"[[:space:]]*:[[:space:]]*true'; then
  echo '创建客户端失败：'
  printf '%s\n' "$CLIENT_RESULT"
  exit 1
fi

SERVER_IP="$(curl -4 -fsS --connect-timeout 8 https://api.ipify.org || true)"
[ -n "$SERVER_IP" ] || SERVER_IP="YOUR_SERVER_IP"

# Store only root-readable output; never commit it.
OUT=/root/vmess-reality-result.txt
umask 077
cat > "$OUT" <<INFO
VLESS + TCP + REALITY
=====================
Server: $SERVER_IP
Port: $PORT
UUID: $UUID
Flow: xtls-rprx-vision
Security: reality
SNI: $SNI
Fingerprint: chrome
Public Key: $PUBLIC_KEY
Short ID: $SHORT_ID
SpiderX: /
Target: $TARGET
Remark: $REMARK

Share link:
vless://$UUID@$SERVER_IP:$PORT?security=reality&encryption=none&type=tcp&flow=xtls-rprx-vision&sni=$(python3 -c 'import urllib.parse; print(urllib.parse.quote("'"$SNI"'"))')&fp=chrome&pbk=$PUBLIC_KEY&sid=$SHORT_ID&spx=%2F#$REMARK
INFO

cat "$OUT"
echo
echo "已保存到：$OUT（权限 600）"
echo '私钥没有输出到客户端链接，也没有写入 GitHub。'
